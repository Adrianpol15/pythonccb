n1=int(input("Ingrese un numero para ver el valor absoluto: "))
res= abs(n1)
print(res)
 
 
