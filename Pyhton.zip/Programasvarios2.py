n1=float(input("Ingrese el primer numero: "))
n2=float(input("Ingrese el segundo numero: "))
n3= n1**n2
print(n3, "es el resultado del primer numero con la potencia del segundo numero: ")