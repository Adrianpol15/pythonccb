n1=str(input("Ingrese el primer nombre sin mayusculas: "))
n2=str(input("Ingrese el segundo nombre sin mayusculas: "))
if n1 == n2:
   print("Son tocayos")
else:
  print("No son tocayos") 