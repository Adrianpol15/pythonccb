a=int(input("Ingrese un numero"))

if a % 2 == 0:
 print("El numero", a, "es par.")
else:
 print("El numero", a, "es impar.")

