print("DIAS DE LA SEMANA")
n1=str(input("Ingrese un dia de la semana: "))
D1=


