n1=str(input("Ingrese un numero de 1 a 7: "))
if n1 == "1": 
  print("Lunes: Que tengas un buen inicio de semana")
elif n1 == "2":
  print("Ingrese otro numero")
elif n1 == "3":
  print("Ingrese otro numero")
elif n1 == "4":
  print("Ingrese otro numero")
elif n1 == "5":
  print("Viernes: Es viernes y el cuerpo lo sabe.")
elif n1 == "6":
  print("Sabado: Hoy es dia para una maraton de peliculas.")
elif n1 == "7":
  print("Domimgo: Pasa tiempo con tu familia y disfruta.")