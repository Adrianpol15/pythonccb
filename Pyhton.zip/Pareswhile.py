n1 = int(input("Ingrese un numero: "))
n2 = 0
while n2 <= n1:
  print(n2)
  n2 += 2
