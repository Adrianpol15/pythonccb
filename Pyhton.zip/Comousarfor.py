frutas=["sandia","naranja","banano","fresa","maracuya","pitaya", "piña","mango","mango verde" ]
for fruta in frutas:
  print(fruta)






for x in range(-100,0,10):
 print(x)
 