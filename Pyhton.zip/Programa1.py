n1=int(input("Ingrese un numero: "))
if n1 == 1000:
  print("ganaste un premio") 
else:
  print("No ganaste un premio")
  