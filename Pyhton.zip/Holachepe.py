print("Hola Chepe")

print("Esto es una suma")
n1=5
n2=2
res=n1+n2
print(res)

print("Esto es una resta")
n1=167
n2=69
res=n1-n2
print(res)

print("Esto es una multiplicacion")
n1=12
n2=24
res=n1*n2
print(res)

print("Esto es una Division")
n1=20
n2=5
res=n1/n2
print(res)

print("Esto es un Modulo")
n1=200
n2=6
res=n1%n2
print(res)