n1 = int(input("Ingrese un numero: "))
n2 = int(input("Ingrese otro numero: "))
if n1<n2:
  print("Es menor es el primer numero")
elif n2<n1:
  print("Es menor es el segundo numero")
elif n2==n1:
  print("Ingrese otros valores estos son iguales")