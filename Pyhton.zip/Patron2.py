print("Programa Patron")

for i in range ( 0, 15): 
 for n in range ( 0, i+1):
  print ( "* ", end="" )
 print()

for n in range (0, 15):  
 for i in range (0, i):
   print("* ", end="" )
 print()