nom=str(input("Ingrese su nombre: "))
edad=float(input("Ingrese su año de nacimiento: "))
a=2022-edad
print("Usted ", nom, " este año va a tener ", a, " años" )