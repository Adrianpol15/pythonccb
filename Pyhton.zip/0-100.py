n1 = 1
while n1 <= 100:
  print(n1)
  n1 += 1