n1 = str(input("Ingresse contraseña: "))
n2 = "hola"
while n2 != n1:
  n1=str(input("ingrese la contraseña correcta: "))
else :
  print("Contraseña correcta")
