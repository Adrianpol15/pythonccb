print("Programa Patron")

for i in range ( 0, 10): #Si se pueden poner mas numeros
 for n in range ( 0, i+1):
  print ( "# ", end="" )
 print()
#Creo que lo tengo

