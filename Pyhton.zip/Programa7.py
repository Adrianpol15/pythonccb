print("Elecciones de partidos")
par=str(input("Elija el partido cual usted vota: A. Rojo B. Verde C. Azul: "))
if par == "A":
  print("Su voto ha sido realizado para el partido Rojo ")
elif par == "B":
  print("Su voto ha sido realizado para el partido verde ")
elif par == "C":
  print("Su voto ha sido realizado para el partido azul ")
else: 
  print("Opcion erronea, vuelva a realizar el voto")