n1=str(input("Ingrese el primer nombre: "))
n2=str(input("Ingrese el segundo nombre: "))
m3=str(input("Ingrese el primer apellido: "))
m4=str(input("Ingrese el segundo apellido: "))

p1=(n1[0])
p2=(n2[0])
p3="@baco.com"
t=p1+p2+"."+m3+m4+p3
print(t)