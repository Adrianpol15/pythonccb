print("Programa Patron")
n=int(input("Ingrese un numero: ")) #aca estara pidiendo la cantidad de # que quieren ingresar.
for i in range ( 0, n): #aca vera el rango de 0 a n
 for n in range ( 0, i+1): #le ira sumando un uno a la cantidad de n hasta llehar al deseao
  print ( "# ", end="" ) #imprime el # y al final hara un salto de linea y eso es todo.
 print()

