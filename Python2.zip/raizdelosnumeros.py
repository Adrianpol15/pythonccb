N = int(input("Ingrese numero N: "))
R = int(input("Ingrese numero R: "))

res = print(N**1/R)