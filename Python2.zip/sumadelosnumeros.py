numero=[]
for i in range (0,10):
  x=int(input("Ingrese un numeros hasta llegar a 10 numeros: "))
  numero.append(x)
print(((list([1]))+(list([9]))))
print(((list([2]))+(list([8]))))