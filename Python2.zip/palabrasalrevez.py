n1= "NOQUIERO"
n2=''.join(reversed(n1))
print("La palabra al revez es: ", n2)  