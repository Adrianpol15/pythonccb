n1=str(input("Ingrese una palabra a revisar: "))
n2=str(input("Caracter a contar: "))

x=n1.count(n2)
print("Se repite: ", x,"Veces")

