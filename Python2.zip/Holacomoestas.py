n1=str(input("Ingrese una palanbra: "))
n2=n1.replace(" ","")
n3=n2.lower()
print(n3)


