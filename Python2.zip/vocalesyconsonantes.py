z=str(input("Ingrese una palabra: "))

x=z[0]
if x == "a":
  print("inicia con una vocal ")
elif x == "e":
  print("inicia con una vocal ")
elif x == "i":
  print("inicia con una vocal ")
elif x == "o":
  print("inicia con una vocal ")
elif x == "u":
  print("inicia con una vocal ")
else:
  print("inicia con una consonante ")
